import os
import logging as log
import numpy as np
import pandas as pd
from datetime import datetime

DATETIME_FORMAT = "%Y-%m-%d %H:%M:%S"

class Metadata:
	def __init__(self, path, start, end):
		self.path = path
		self.start = start
		self.end = end
		
	def print(self):
		print(self.path, self.start, self.end)

class Data:
	def __init__(self, rootDir = '.'):
		self.table = []
		self.headers = []
		self.rootDir = rootDir
		self.metadata = []
		self.updateMetadata()
		
	def getNewCSVFiles(self):
		retVal = []
		allCSVFiles = self.getAllCSVFiles()
		
		currentCSVFiles = []
		for m in self.metadata:
			currentCSVFiles.append(m.path)
			
		for csvFile in allCSVFiles:
			if csvFile not in currentCSVFiles:
				retVal.append(csvFile)
		
		return retVal
		
	def updateMetadata(self):
		newCSVFiles = self.getNewCSVFiles()
		
		for file in newCSVFiles:
			with open(file, "r") as f:
				start = end = ""
				lines = f.read().splitlines()
				#get start timestamp
				for line in lines:
					try:
						dateTimeString = line.split(",")[0]
						start = datetime.strptime(dateTimeString, DATETIME_FORMAT)
						break
					except Exception as e:
						pass
				#get end timestamp
				try:
					dateTimeString = lines[-1].split(",")[0]
					end = datetime.strptime(dateTimeString, DATETIME_FORMAT)
				except:
					log.warning("Failed to get end time form %s" % (lines[-1]))
				
				# if start and end times ar ok, append them to metadata array
				if start != "" and end != "":
					self.metadata.append(Metadata(file, start, end))
		
	def getTimestampRange(self):
		min = self.metadata[0].start
		max = self.metadata[0].end
		for i in range (1, len(self.metadata)):
			if min > self.metadata[i].start:
				min = self.metadata[i].start
				
			if max < self.metadata[i].start:
				max = self.metadata[i].end
				
		return [min, max]
				
		
	def selectCSVFiles(self, range):
		start, end = range
		retVal = []
		for m in self.metadata:
			#check if two ranges overlap
			if start <= m.end and end >= m.start:
				retVal.append(m.path)
				
		return retVal
		
	def getAllCSVFiles(self):
		retVal = []
		for root, dirs, files in os.walk(self.rootDir):
			for file in files:
				if file.endswith(".csv"):
					csv = os.path.join(root, file)
					retVal.append(csv)
					log.debug("Found %s" % csv)
					
		if retVal == []:
			log.error("No CSV files found in %s!" % (self.rootDir))
			sys.exit()
		return retVal
		
	def getHeaders(self, file):
		with open(file, 'r') as f:
			self.headers = f.readline().split(',')
			
	def genDt(self):
		retVal = []
		for name in self.headers:
			if "time" in name:
				type = "datetime64[us]"
			else:
				type = "f4"
			retVal.append((name, type))
		return retVal
	
	def load(self, timeRange = []):
		if timeRange == []:
			fileList = self.getAllCSVFiles(self.rootDir)
		else:
			fileList = self.selectCSVFiles(timeRange)
			
		self.getHeaders(fileList[0])
		self.table = np.concatenate(
			[np.genfromtxt(file, 
						skip_header = 1, 
						delimiter=',',
						converters={0: lambda x: pd.to_datetime(x.decode('utf-8'), format="%Y-%m-%d %H:%M:%S")}) for file in fileList], 
			axis=0) 
		
		self.genDt()
		
		self.table = np.array(self.table, self.genDt())
		self.table = np.sort(self.table, axis=0)
		log.debug("Loaded %d columns and %d lines" % (self.getColumnCount(), self.getLineCount()))
		log.debug("Column headers: %s", str(self.headers))
	
	def getColumnCount(self):
		return (len(self.table[0]))
	
	def getLineCount(self):
		return np.size(self.table, 0)
	
	def print(self):
		np.set_printoptions(suppress=True)
		for line in self.table:
			print(line)

