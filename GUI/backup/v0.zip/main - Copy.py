from PyQt5 import QtCore, QtGui, uic, QtWidgets
from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
from matplotlib.figure import Figure
import matplotlib.pyplot as plt
import matplotlib as mpl

from mplwidget import MplWidget

import sys
import logging as log
import argparse

import dataLoader
from dataLoader import Data

LOG_FORMAT = "%(asctime)s %(levelname)-8s: %(message)s\t"
TIMESTAMP_FORMAT = '%d-%m-%YT%H:%M:%S'

qtCreatorFile = "datalogger.ui" # Enter file here.
Ui_MainWindow, QtBaseClass = uic.loadUiType(qtCreatorFile)

class MyApp(QtWidgets.QMainWindow, Ui_MainWindow):
	def __init__(self):
		QtWidgets.QMainWindow.__init__(self)
		Ui_MainWindow.__init__(self)
		self.setupUi(self)
		
		for widget in self.allTab.children():
			if isinstance(widget, MplWidget):
				widget.canvas.ax.set_xlabel ('time', fontsize=10)
				widget.canvas.ax.set_ylabel ('voltage, V', fontsize= 10)
				widget.canvas.ax.autoscale(enable=True, axis='both', tight=None)
				widget.canvas.draw()
				
		#disable toolbars
		win = self.allTab.window()
		toolbars = win.findChildren(QtWidgets.QToolBar)
		for t in toolbars:
			t.setVisible(False)
				
		self.showMaximized()
		
		dataTable = dataLoader.Data()
		dataTable.readCSVFiles() 
		table = dataTable.getDataTable()
		print (table['time'])
		print (table['x'])
		self.widget.canvas.ax.scatter(table['time'], table['x'])

if __name__ == "__main__":
	#parse input arguments
	parser = argparse.ArgumentParser()
	parser.add_argument('-v', '--verbosity', action="count", 
                        help="-v: WARNING, -vv: INFO, -vvv: DEBUG")
	args = parser.parse_args()
	
	#setup verbosity level
	if args.verbosity:
		if args.verbosity >= 3:
			log.basicConfig(format=LOG_FORMAT,  datefmt=TIMESTAMP_FORMAT, level=log.DEBUG)
		elif args.verbosity == 2:
			log.basicConfig(format=LOG_FORMAT, datefmt=TIMESTAMP_FORMAT, level=log.INFO)
		elif args.verbosity == 1:
			log.basicConfig(format=LOG_FORMAT, datefmt=TIMESTAMP_FORMAT, level=log.WARNING)
		else:
			log.basicConfig(format=LOG_FORMAT, datefmt=TIMESTAMP_FORMAT, level=log.ERROR)

	app = QtWidgets.QApplication(sys.argv)
	window = MyApp()
	window.show()
	sys.exit(app.exec_())